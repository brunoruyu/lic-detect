#!/bin/bash

echo "🚀 Instalando Licitación Detector..."
echo ""

# Check Python version
python_version=$(python3 --version 2>&1 | awk '{print $2}')
echo "✓ Python version: $python_version"

# Create virtual environment
if [ ! -d "venv" ]; then
    echo "📦 Creando entorno virtual..."
    python3 -m venv venv
    echo "✓ Virtual environment creado"
else
    echo "✓ Virtual environment ya existe"
fi

# Activate venv
echo "🔧 Activando venv..."
source venv/bin/activate

# Install dependencies
echo "📥 Instalando dependencias..."
pip install --upgrade pip
pip install -r requirements.txt
echo "✓ Dependencias instaladas"

# Create directories
echo "📁 Creando directorios..."
mkdir -p logs data tests
echo "✓ Directorios creados"

# Create .env template if not exists
if [ ! -f ".env" ]; then
    echo "📝 Creando template .env..."
    cat > .env << EOL
# Rofex/Primary Credentials
ROFEX_USER=your_user
ROFEX_PASSWORD=your_password
ROFEX_ACCOUNT=your_account

# Notificaciones (opcional)
TELEGRAM_BOT_TOKEN=
TELEGRAM_CHAT_ID=

# Email (opcional)
EMAIL_FROM=
EMAIL_TO=
SMTP_SERVER=smtp.gmail.com
EOL
    echo "✓ Template .env creado - CONFIGURAR CON TUS CREDENCIALES"
else
    echo "✓ .env ya existe"
fi

echo ""
echo "✅ Instalación completada!"
echo ""
echo "📋 Próximos pasos:"
echo "1. Editar .env con tus credenciales"
echo "2. Ejecutar test: python main.py --mode paper --once"
echo "3. Ver README.md para más detalles"
echo ""
echo "🎯 Para activar el venv en el futuro:"
echo "   source venv/bin/activate"
